package unitTests;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Main.Contact;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.10
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the ContactService class which was identified to have the following requirements:
 * Contact Class Requirements
 * 	    The contact object shall have a required unique contact ID string that cannot be longer than 10 characters. The contact ID shall not be null and shall not be updatable.
 * 	    The contact object shall have a required firstName String field that cannot be longer than 10 characters. The firstName field shall not be null.
 * 	    The contact object shall have a required lastName String field that cannot be longer than 10 characters. The lastName field shall not be null.
 * 	    The contact object shall have a required phone String field that must be exactly 10 digits. The phone field shall not be null.
 * 	    The contact object shall have a required address field that must be no longer than 30 characters. The address field shall not be null.
 */

class ContactTest {
	
	// ##############################################
	// #### Common values used by multiple tests ####
	// ##############################################
	
	//ID String that cannot be longer than 10 characters
	String ID = "12345abcde";// 10 char
	String IDShort = "12345abcd";// 9 char
	String IDLong = "12345abcdef";// 11 char
	
	//firstName String that cannot be longer than 10 characters
	String firstName = "Persephone";// 10 char
	String firstNameShort = "Valentina";// 9 char
	String firstNameLong = "Christopher";// 11 char
	
	//lastName String that cannot be longer than 10 characters
	String lastName = "MacDonnell";// 10 char
	String lastNameShort = "McDonnell";// 9 char
	String lastNameLong = "Fredrickson";// 11 char
	

	//phone String that cannot be longer than 10 digits
	String phone = "(216) 245-2368";// 10 digits
	String phoneShort = "(26) 245-2368";// 9 digits
	String phoneLong = "1 (216) 245-2368";// 11 digits
	

	//address String that cannot be longer than 30 characters
	String address = "1600 Pennsylvania Avenue NW, W";// 30 char
	String addressShort = "1600 Pennsylvania Avenue NW, ";// 29 char
	String addressLong = "1600 Pennsylvania Avenue NW, Wa";// 31 char
	
	// ##############################################
	// ############# Constructor  Tests #############
	// ##############################################
	
	// Constructor base test; verifies that an object can be created
	@Test
	void constructorBase() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		assertTrue(contact.getID().equals(ID));
		assertTrue(contact.getFirstName().equals(firstName));
		assertTrue(contact.getLastName().equals(lastName));
		assertTrue(contact.getPhone().equals("2162452368"));
		assertTrue(contact.getAddress().equals(address));
	}
	
	// ################## ID tests ##################
	// The contact object shall have a required unique contact ID string that cannot be longer than 10 characters. The contact ID shall not be null and shall not be updatable.
    
	// Testing if class constructor responds properly when ID is null
	@Test
	void constructorIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, firstName, lastName, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when ID is zero length
	@Test
	void constructorIDIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("", firstName, lastName, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when ID is exactly ten
	@Test
	void constructorIDIsExactlyTen() {
		Contact contact = new Contact(ID, firstName, lastName, phone,  address);
		assertTrue(contact.getID().equals(ID));
	}
	
	// Testing if class constructor responds properly when ID length exceeds 10
	@Test
	void constructorIDIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(IDLong, firstName, lastName, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when ID length is under 10
	@Test
	void constructorIDIsShort() {
		Contact contact = new Contact(IDShort, firstName, lastName, phone,  address);
		assertTrue(contact.getID().equals(IDShort));
	}
	
	// ################## firstName tests ##################
	// The contact object shall have a required firstName String field that cannot be longer than 10 characters. The firstName field shall not be null.
	
	// Testing if class constructor responds properly when first name is null
	@Test
	void constructorFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, null, lastName, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when first name is zero length
	@Test
	void constructorFirstNameIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, "", lastName, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when first name is exactly ten characters
	@Test
	void constructorFirstNameIsExactlyTen() {
		Contact contact = new Contact(ID, firstName, lastName, phone,  address);
		assertTrue(contact.getFirstName().equals(firstName));
	}
	
	// Testing if class constructor responds properly when first name is more than ten characters
	@Test
	void constructorFirstNameIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstNameLong, lastName, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when first name is under ten characters
	@Test
	void constructorFirstNameIsShort() {
		Contact contact = new Contact(ID, firstNameShort, lastName, phone,  address);
		assertTrue(contact.getFirstName().equals(firstNameShort));
	}
	
	// ################## lastName tests ##################
	// The contact object shall have a required lastName String field that cannot be longer than 10 characters. The lastName field shall not be null.
	
	// Testing if class constructor responds properly when last name is null
	@Test
	void constructorLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, null, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when the last name is zero length
	@Test
	void constructorLastNameIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, "", phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when the last name is exactly ten characters
	@Test
	void constructorLastNameIsExactlyTen() {
		Contact contact = new Contact(ID, firstName, "whoUGonCal", phone,  address);
		assertTrue(contact.getLastName().equals("whoUGonCal"));
	}
	
	// Testing if class constructor responds properly when the last name is more than ten characters
	@Test
	void constructorLastNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastNameLong, phone,  address);
		});
	}
	
	// Testing if class constructor responds properly when the last name is less than ten characters
	@Test
	void constructorLastNameIsShort() {
		Contact contact = new Contact(ID, firstName, lastNameShort, phone,  address);
		assertTrue(contact.getLastName().equals(lastNameShort));
	}
	
	// ################## phone tests ##################
	// The contact object shall have a required phone String field that must be exactly 10 digits. The phone field shall not be null.
	
	// Testing if class constructor responds properly when the phone number is null
	@Test
	void constructorPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, null, address);
		});
	}
	
	// Testing if class constructor responds properly when the phone number is zero length
	@Test
	void constructorPhoneIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, "", address);
		});
	}
	
	// Testing if class constructor responds properly when there are ten digits within the phone number
	@Test
	void constructorPhoneIsExactlyTen() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		assertTrue(contact.getPhoneFormatted().equals(phone));
	}
	
	// Testing if class constructor responds properly when the phone number has more than ten digits
	@Test
	void constructorPhoneIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, phoneLong, address);
		});
	}
	
	// Testing if class constructor responds properly when the phone number has less than ten digits
	@Test
	void constructorPhoneIsTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, phoneShort, address);
		});
	}
	
	// Testing if class constructor responds properly when supplied with a string which contains non-numeric characters
	@Test
	void constructorPhoneStripsChars() {
		Contact contact = new Contact(ID, firstName, lastName, "a0b1c2d3e4f5g6h7i8.9k!@#", address);
		assertTrue(contact.getPhone().equals("0123456789"));
	}
	
	// Testing if class constructor formats properly when supplied with a string which contains non-numeric characters
	@Test
	void constructorFormattedFormats() {
		Contact contact = new Contact(ID, firstName, lastName, "a0b1c2d3e4f5g6h7i8.9k!@#", address);
		assertTrue(contact.getPhoneFormatted().equals("(012) 345-6789"));
	}
	
	// ################## address tests ##################
	// The contact object shall have a required address field that must be no longer than 30 characters. The address field shall not be null.

	// Testing if class constructor responds properly when address is null
	@Test
	void constructorAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, phone,  null);
		});
	}
	
	// Testing if class constructor responds properly when address is zero length
	@Test
	void constructorAddressIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, phone,  "");
		});
	}
	
	// Testing if class constructor responds properly when address is exactly thirty characters
	@Test
	void constructorAddressIsExactlyThirty() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		assertTrue(contact.getAddress().equals(address));
	}
	
	// Testing if class constructor responds properly when address is more than thirty characters
	@Test
	void constructorAddressIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(ID, firstName, lastName, phone, addressLong);
		});
	}
	
	// Testing if class constructor responds properly when address is less than thirty characters
	@Test
	void constructorAddressIsShort() {
		Contact contact = new Contact(ID, firstName, lastName, phone, addressShort);
		assertTrue(contact.getAddress().equals(addressShort));
	}

	// ##############################################
	// ############ Setter:getter Tests #############
	// ##############################################

	// ############ FirstName Set/Get tests ##############
	

	// Testing if setter method responds properly when first name is null
	@Test
	void setterFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setFirstName(null);
		});
	}
	
	// Testing if setter method responds properly when first name is zero length
	@Test
	void setterFirstNameIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setFirstName("");
		});
	}
	
	// Testing if setter method responds properly when first name is exactly ten characters
	@Test
	void setterFirstNameIsExactlyTen() {
		Contact contact = new Contact(ID, "notTen", lastName, phone, address);
		contact.setFirstName(firstName);
		assertTrue(contact.getFirstName().equals(firstName));
	}
	
	// Testing if setter method responds properly when first name is too long
	@Test
	void setterFirstNameIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setFirstName(firstNameLong);
		});
	}
	
	// Testing if setter method responds properly when first name is exactly ten characters
	@Test
	void setterFirstNameIsShort() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		contact.setFirstName(firstNameShort);
		assertTrue(contact.getFirstName().equals(firstNameShort));
	}

	// ############ LastName Set/Get tests ##############
	
	// Testing if setter method responds properly when last name is null
	@Test
	void setterLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setLastName(null);
		});
	}
	
	// Testing if setter method responds properly when last name is zero length
	@Test
	void setterLastNameIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setLastName("");
		});
	}
	// Testing if setter method responds properly when last name is exactly ten characters
	@Test
	void setterLastNameIsExactlyTen() {
		Contact contact = new Contact(ID, firstName, "notTen", phone, address);
		contact.setLastName(lastName);
		assertTrue(contact.getLastName().equals(lastName));
	}
	// Testing if setter method responds properly when the last name is too long
	@Test
	void setterLastNameIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setLastName(lastNameLong);
		});
	}
	
	// Testing if setter method responds properly when last name is less than ten characters
	@Test
	void setterLastNameIsShort() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		contact.setLastName(lastNameShort);
		assertTrue(contact.getLastName().equals(lastNameShort));
	}
	
	// ############ Phone Set/Get tests ##############
	
	// Testing if setter method responds properly when the phone is null
	@Test
	void setterPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setPhone(null);
		});
	}
	
	// Testing if setter method responds properly when the phone number is zero length
	@Test
	void setterPhoneIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setPhone("");
		});
	}
	// Testing if setter method responds properly when the phone number is exactly ten digits
	@Test
	void setterPhoneIsExactlyTen() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		contact.setPhone("0123456789");
		assertTrue(contact.getPhone().equals("0123456789"));
	}
	
	// Testing if setter method responds properly when the phone number is too long
	@Test
	void setterPhoneIsLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setPhone(phoneLong);
		});
	}
	
	// Testing if setter method responds properly when the phone number is too short
	@Test
	void setterPhoneIsShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setPhone(phoneShort);
		});
	}
	
	// Testing if setter method responds properly when supplied with phone number which contains non-numeric characters
	@Test
	void setterPhoneStripsChars() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		contact.setPhone("a0b1c2d3e4f5g6h7i8.9k!@#");
		assertTrue(contact.getPhone().equals("0123456789"));
	}
	
	// Testing if setter method formats properly
	@Test
	void setterPhoneFormattedFormats() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		contact.setPhone("a0b1c2d3e4f5g6h7i8.9k!@#");
		assertTrue(contact.getPhoneFormatted().equals("(012) 345-6789"));
	}
	
	// ############ address Set/Get tests ##############
	
	// Testing if setter method responds properly when address is null
	@Test
	void setterAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setAddress(null);
		});
	}
	
	// Testing if setter method responds properly when  address is zero length
	@Test
	void setterAddressIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setAddress("");
		});
	}
	
	// Testing if setter method responds properly when address is exactly thirty characters
	@Test
	void setterAddressIsExactlyThirty() {
		Contact contact = new Contact(ID, firstName, lastName, phone, "notThirty");
		contact.setAddress(address);
		assertTrue(contact.getAddress().equals(address));
	}
	
	// Testing if setter method responds properly when address is too long
	@Test
	void setterAddressIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Contact contact = new Contact(ID, firstName, lastName, phone, address);
			contact.setAddress(addressLong);
		});
	}
	
	// Testing if setter method responds properly when address is less than thirty characters
	@Test
	void setterAddressIsShort() {
		Contact contact = new Contact(ID, firstName, lastName, phone, address);
		contact.setAddress(addressShort);
		assertTrue(contact.getAddress().equals(addressShort));
	}
	
}
