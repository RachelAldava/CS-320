package unitTests;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import Main.Counter;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.11
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the Counter class, which was developed in order to provide 
 * 	various strategies for generating non-repeating string based ID values
 * 
*/
class CounterTest {
	
	@Test
	void numberSanity() {
		String current = "";
		Counter counter = Counter.newNumberCounter();
		for (int i = 1; i <= 100; i++) {
			current = counter.getNext();
			assertTrue(current.equals(String.valueOf(i)));
		}
	}
	
	@Test
	void hexSanity() {
		String current = "";
		Counter counter = Counter.newHexCounter();
		char[] dict = new char[]{'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
		
		// As of this line, decimal val: null
		for (int i = 1; i <= 15; i++) {
			current = counter.getNext();
			assertTrue(current.equals(String.valueOf(dict[i])));
		}
		// As of this line, decimal val: 15
		current = counter.getNext();
		assertTrue(current.equals("10"));
		// As of this line, decimal val: 16
		for (int i = 1; i <= 15; i++) counter.getNext();
		current = counter.getNext();
		assertTrue(current.equals("20"));
		// As of this line, decimal val: 32
		for (int i = 1; i <= 999967; i++) counter.getNext();
		current = counter.getNext();
		// As of this line, decimal val: 1,000,000
		assertTrue(current.equals("F4240"));

	}
	
	@Test
	void symbolSanity() {
		String current = "";
		Counter counter = Counter.newSymbolCounter();

		current = counter.getNext();
		assertTrue(current.equals("\""));
		// As of this line, decimal val: 1
		for (int i = 1; i <= 30; i++) counter.getNext();
		current = counter.getNext();
		assertTrue(current.equals("A"));
		// As of this line, decimal val: 32
		for (int i = 1; i <= 60; i++) counter.getNext();
		current = counter.getNext();
		assertTrue(current.equals("~"));
		// As of this line, decimal val: 93
		current = counter.getNext();
		assertTrue(current.equals("\"!"));
		// As of this line, decimal val: 94
	}
	
	@Test
	void alphaSanity() {
		String current = "";
		Counter counter = Counter.newAlphaCounter();

		current = counter.getNext();
		assertTrue(current.equals("B"));
		// As of this line, decimal val: 1
		for (int i = 1; i <= 23; i++) counter.getNext();
		current = counter.getNext();
		assertTrue(current.equals("Z"));
		// As of this line, decimal val: 25
		current = counter.getNext();
		assertTrue(current.equals("BA"));
		// As of this line, decimal val: 26
	}
	
	@Test
	void inSanity() {
		String current = "";
		Counter counter = Counter.newBrokenCounter("Have I gone mad?");

		for (int i = 1; i <= 100; i++) {
			current = counter.getNext();
			counter.next();
			assertTrue(current.equals("Have I gone mad?"));
		}
	}
	
	@Test
	void extendedSanity() {
		char zero = 0;
		char one = 1;
		char last = 65535;
		
		String current = "";
		Counter counter = Counter.newExtCharCounter();

		current = counter.getNext();
		assertTrue(current.equals(String.valueOf(one)));
		// As of this line, decimal val: 1
		for (int i = 1; i <= 65533; i++) counter.getNext();
		current = counter.getNext();
		assertTrue(current.equals(String.valueOf(last)));
		// As of this line, decimal val: 65534
		current = counter.getNext();
		assertTrue(current.equals((String.valueOf(one) + zero)));
		// As of this line, decimal val: 65535
	}
	
	@Test
	void test() {
		
		
	}
}
