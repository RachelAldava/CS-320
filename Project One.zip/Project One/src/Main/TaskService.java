package Main;
import java.util.HashMap;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.03.29
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class was developed as my interpretation from the identified requirements:
 * Task Service Requirements
 * 
 *     The task service shall be able to add tasks with a unique ID.
 *     The task service shall be able to delete tasks per task ID.
 *     The task service shall be able to update task fields per task ID. The following fields are updatable:
 *         Name
 *         Description
 */
public class TaskService {
	
	//##################################
	//####### Instance Variables #######
	//##################################
	
	// ID:Object key; This houses references to Task objects
	private HashMap<String, Task> tasks = new HashMap<String, Task>();
	
	// This object will provide sequential ID strings.
	private Counter IdCounter;

	//##################################
	//########## Constructors ##########
	//##################################
	
	/**
	 * Creates a new blank TaskService object
	 * @return new TaskService object
	 */
	public TaskService() {
		this.IdCounter = Counter.newSymbolCounter();
	}
	
	/**
	 * Creates a new blank TaskService object using IDs generated from the supplied counter.
	 * @param A Counter object
	 * @return new TaskService object
	 */
	public TaskService(Counter counter) {
		this.IdCounter = counter;
	}
	
	
	//##################################
	//######### Class  Methods #########
	//##################################
	
	
	//####### Creation : Deletion ######
	
	/**
	 * Creates a new Task object
	 * @param ID
	 * @param name
	 * @param description
	 */
	// The task service shall be able to add tasks with a unique ID.
	public Task newTask(String name, String description) {
		// Collect values
		Task task = new Task(IdCounter.getNext(), name, description);
		
		// Check for conflicting IDs
		// At time of writing (version 0.1), this can only occur if there is an issue 
		// within the Counter class or its children.
		if (tasks.containsKey(task.getID())) throw new IllegalArgumentException("ERROR: Conflicting ID supplied");
		
		// Add task to list and return
		tasks.put(task.getID(), task);
		return task;
	}
	
	/**
	 * Deletes a Task object
	 * @param ID
	 */
	// The task service shall be able to delete tasks per task ID.
	public void deleteTask(String ID) {
		if (!tasks.containsKey(ID)) throw new IllegalArgumentException("ID does not exist" ); // Is not in hashmap;
		tasks.remove(ID);
	}
	
	//####### Getters : Setters ########
	
	/**
	 * Returns a new Task object
	 * @param ID
	 * @return Task
	 */
	public Task getTaskID(String ID) {
		if (!tasks.containsKey(ID)) throw new IllegalArgumentException("ID does not exist" ); // Is not in hashmap;
		return tasks.get(ID);
	}
	
	/**
	 * Returns a task's name
	 * @param ID
	 * @return name
	 */
	public String getName(String ID) {
		return getTaskID(ID).getName();
	}
	
	/**
	 * Returns a task's description
	 * @param ID
	 * @return description
	 */
	public String getDescription(String ID) {
		return getTaskID(ID).getDescription();
	}
	
	/**
	 * Changes name
	 * @param ID
	 * @param name
	 */
	public void setTaskName(String ID, String name) {
		getTaskID(ID).setName(name);
	}
	
	/**
	 * Changes description
	 * @param ID
	 * @param description
	 */
	public void setTaskDescription(String ID, String description) {
		getTaskID(ID).setDescription(description);
	}
}
