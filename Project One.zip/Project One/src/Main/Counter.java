package Main;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.11
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This an abstract class which instantiates different counters and provides
 * 		a unified framework for child methods to @Override 
 * 
 * Use case: 
 * 		Instantiating and operating various Counter child classes in an agnostic manner.
 * 
 * Usage: Call a newCounter method, then use getNext(), next(), or get() to operate.
*/

public abstract class Counter {
	protected String ID;

	/**
	 * An inefficient way to count in base-10 digits
	 * @return new base-10 string counter
	 */
	public static Counter newNumberCounter() {
		return new DictCounter(new char[]{'0','1','2','3','4','5','6','7','8','9'});
	}
	
	/**
	 * A hexidecimal counter of dubious efficiency
	 * @return new base-16 string counter
	 */
	public static Counter newHexCounter() {
		return new DictCounter(new char[]{'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'});
	}
	
	/**
	 * A String based alpha-numeric and special character counter.
	 * @return new string based counter
	 */
	public static Counter newSymbolCounter() {
		return new CharCounter(33,126);
	}
	
	/**
	 * A String based counter which, while illegible to humans, 
	 * 		will produce an enormous variety of characters.
	 * 		A string no longer than 5 characters can contain 
	 * 		((5^65535) + (4^65535) + ... + (1^65535)) values (I think?).
	 * 		It is probably a really bad way to store data, but it's fun!
	 * @return new string based counter
	 */
	public static Counter newExtCharCounter() {
		return new CharCounter(0,65535);
	}
	
	/**
	 * A String based counter which only uses the 26 English capital letters.
	 * @return new string based counter
	 */
	public static Counter newAlphaCounter() {
		return new CharCounter(65,90);
	}
	
	/**
	 * A String based "counter" which only returns the originally supplied string
	 * This type of counter is useful for producing counting collisions for testing purposes.
	 * @return new broken counter
	 */
	public static Counter newBrokenCounter(String string) {
		return new BrokenCounter(string);
	}
	
	
	// Abstract methods
	public abstract String getNext();
	public abstract void next();
	public abstract String get();

}
