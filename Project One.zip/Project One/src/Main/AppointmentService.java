package Main;

import java.util.Date;
import java.util.HashMap;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.06
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the Appointment class which was identified to have the following requirements:
 * Appointment Service Requirements
 * 
 *    The appointment service shall be able to add appointments with a unique appointment ID.
 *    The appointment service shall be able to delete appointments per appointment ID.
*/
public class AppointmentService {

	
	//##################################
	//####### Instance Variables #######
	//##################################
	
	// ID:Object key; This houses references to Appointment objects
	private HashMap<String, Appointment> appointments = new HashMap<String, Appointment>();
	
	// This object will provide sequential ID strings.
	private Counter IdCounter;

	//##################################
	//########## Constructors ##########
	//##################################
	
	/**
	 * Creates a new blank AppointmentService object
	 * @return new AppointmentService object
	 */
	public AppointmentService() {
		this.IdCounter = Counter.newSymbolCounter();
	}
	
	/**
	 * Creates a new blank AppointmentService object using IDs generated from the supplied counter.
	 * @param A Counter object
	 * @return new AppointmentService object
	 */
	public AppointmentService(Counter counter) {
		this.IdCounter = counter;
	}
	
	
	//##################################
	//######### Class  Methods #########
	//##################################
	
	
	//####### Creation : Deletion ######
	
	/**
	 * Creates a new Appointment object
	 * @param ID
	 * @param date
	 * @param description
	 */
	// The appointment service shall be able to add appointments with a unique ID.
	public Appointment newAppointment(Date date, String description) {
		// Collect values
		Appointment appointment = new Appointment(IdCounter.getNext(), date, description);
		
		// Check for conflicting IDs
		// At time of writing (version 0.1), this can only occur if there is an issue 
		// within the Counter class or its children.
		if (appointments.containsKey(appointment.getID())) throw new IllegalArgumentException("ERROR: Conflicting ID supplied");
		
		// Add appointment to list and return
		appointments.put(appointment.getID(), appointment);
		return appointment;
	}
	
	/**
	 * Deletes an Appointment object
	 * @param ID
	 */
	// The appointment service shall be able to delete appointments per appointment ID.
	public void deleteAppointment(String ID) {
		if (!appointments.containsKey(ID)) throw new IllegalArgumentException("ID does not exist" ); // Is not in hashmap;
		appointments.remove(ID);
	}
	
	//####### Getters : Setters ########
	
	/**
	 * Returns an new Appointment object
	 * @param ID
	 * @return Appointment
	 */
	public Appointment getAppointmentID(String ID) {
		if (!appointments.containsKey(ID)) throw new IllegalArgumentException("ID does not exist" ); // Is not in hashmap;
		return appointments.get(ID);
	}
	
	/**
	 * Returns an appointment's date
	 * @param ID
	 * @return date
	 */
	public Date getDate(String ID) {
		return getAppointmentID(ID).getDate();
	}
	
	/**
	 * Returns an appointment's description
	 * @param ID
	 * @return description
	 */
	public String getDescription(String ID) {
		return getAppointmentID(ID).getDescription();
	}
	
	/**
	 * Changes date
	 * @param ID
	 * @param date
	 */
	public void setAppointmentDate(String ID, Date date) {
		getAppointmentID(ID).setDate(date);
	}
	
	/**
	 * Changes description
	 * @param ID
	 * @param description
	 */
	public void setAppointmentDescription(String ID, String description) {
		getAppointmentID(ID).setDescription(description);
	}

}
