package unitTests;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Main.Counter;
import Main.Appointment;
import Main.AppointmentService;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.11
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the Appointment class which was identified to have the following requirements:
 * Appointment Service Requirements
 * 
 *    The appointment service shall be able to add appointments with a unique appointment ID.
 *    The appointment service shall be able to delete appointments per appointment ID.
*/
class AppointmentServiceTest {


	// ##############################################
	// #### Common values used by multiple tests ####
	// ##############################################

	// Date field cannot be in the past
	Date date = new Date(32503701600000L);// y3k
	
	//Description String field that cannot be longer than 50 characters
	String description = "Lorem ipsum sed aliena a republica nostra videtur."; // 50 characters

	
	

	// Testing if we can create a new AppointmentService object
	// Testing if we can create a new appointment object
	// TEST PARTIALLY SATISFIES REQUIREMENT The appointment service shall be able to add appointments with a unique ID.
	@Test
	void newServiceFunctions() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = service.newAppointment(date, description);
		assertTrue(appointment.getID().equals("\""));
	}
	
	// Testing if we can create a AppointmentService object using overloaded constructor
	@Test
	void newServiceCustomCounterFunctions() {
		Counter counter = Counter.newNumberCounter();
		AppointmentService service = new AppointmentService(counter);
		Appointment appointment = service.newAppointment(date, description);
		assertTrue(appointment.getID().equals("1"));
	}
	
	// Testing if the service can retrieve an appointment by its ID
	@Test
	void serviceCanRetrieveAppointmentObject() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = service.newAppointment(date, description);
		Appointment retrievedAppointment = service.getAppointmentID(appointment.getID());
		assertTrue(retrievedAppointment.getID().equals(appointment.getID()));
	}
	
	// Testing if getAppointmentID will throw an error when supplied with a bad id
	@Test
	void getAppointmentIDThrowsError() {
		AppointmentService service = new AppointmentService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.getAppointmentID("Catiline");
		});
	}
	
	// Testing if we can delete a appointment object
	// TEST SATISFIES REQUIREMENT The appointment service shall be able to delete appointments per appointment ID.
	@Test
	void deleteAppointmentFunctions() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = service.newAppointment(date, description);
		service.deleteAppointment(appointment.getID());
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteAppointment(appointment.getID());
		});
	}
	
	// Testing if we can create multiple appointments with the service and appropriately retrieve them.
	@Test
	void ServiceCanAddMultipleAppointments() {
		AppointmentService service = new AppointmentService(Counter.newNumberCounter());
		for (int i = 0; i < 99; i++) {
			service.newAppointment(date, description);
		}
		Appointment appointment = service.newAppointment(date, description);
		String retrievedID = service.getAppointmentID(appointment.getID()).getID();
		assertTrue(retrievedID.equals("100"));
	}
	
	// Setter and getter tests
	@Test
	void updateFieldsFunctions() {
		AppointmentService service = new AppointmentService();
		Appointment appointment = service.newAppointment(date, description);
		Date farFuture = new Date(99999999999999L);
		service.setAppointmentDate(appointment.getID(), farFuture);
		service.setAppointmentDescription(appointment.getID(),"Senatus haec intellegit, Consul videt; vivit?");
		assertTrue(service.getDate(appointment.getID()).equals(farFuture));
		assertTrue(service.getDescription(appointment.getID()).equals("Senatus haec intellegit, Consul videt; vivit?"));
	}
	
	// Testing for error handling in the event of colliding ID values
	// TEST SATISFIES REQUIREMENT: The appointment service shall be able to add appointments with a unique ID.
	@Test
	void CollidingIDThrowsError() {
		// NOTE: This type of Counter should cause AppointmentService to attempt to use "1" for all IDs
		Counter counter = Counter.newBrokenCounter("1");
		AppointmentService service = new AppointmentService(counter);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.newAppointment(date, description);
			service.newAppointment(date, description);
		});
	}

}
