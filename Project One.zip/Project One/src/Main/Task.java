package Main;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.03.27
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class was developed as my interpretation from the identified requirements:
 * Task Class Requirements
 * 
 *     The task object shall have a required unique task ID String that cannot be longer than 10 characters. The task ID shall not be null and shall not be updatable.
 *     The task object shall have a required name String field that cannot be longer than 20 characters. The name field shall not be null.
 *     The task object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.
 * 
 */
public class Task {

	/*
	 * Attributes
	 */
	
	private final String ID;
	private String name;
	private String description;
	
	/*
	 * Methods
	 */
	
	/**
	 * Constructor
	 * @param ID 
	 * @param name 
	 * @param description
	 * @return new task
	 */
	public Task (String ID, String name, String description) {
		checkValidID(ID);
		this.ID = ID;
		
		checkValidName(name);
		this.name = name;
		
		checkValidDescription(description);
		this.description = description;		
	}
	
	/*
	 * Input validation
	 */
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match ID criteria
	 * @param ID
	 */
	private static void checkValidID(String ID) {
		//// The contact object shall have a required unique contact ID string that cannot be longer than 10 characters. The contact ID shall not be null and shall not be updatable.
		if (ID == null || ID == "") throw new IllegalArgumentException("ID cannot be blank" ); // Is not null or zero- length
		if (ID.length() > 10) throw new IllegalArgumentException("ID cannot be longer than 10 characters" ); // is not more than ten characters
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match name criteria
	 * @param name
	 */
	private static void checkValidName(String name) {
		// The contact object shall have a required name String field that cannot be longer than 20 characters. The name field shall not be null.
		if (name == null || name == "") throw new IllegalArgumentException("Name cannot be blank" );
		if (name.length() > 20) throw new IllegalArgumentException("Name cannot be longer than 20 characters" ); // is not more than twenty characters
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match description criteria
	 * @param description
	 */
	private static void checkValidDescription(String description) {
		// The contact object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.
		if (description == null || description == "") throw new IllegalArgumentException("Description cannot be blank" );
		if (description.length() > 50) throw new IllegalArgumentException("Description cannot be longer than 50 characters" ); // is not more than fifty characters
	}

	
	/*
	 * Setters
	 */
	
	/**
	 * Sets a new name
	 * @param name
	 */
	public void setName(String name) {
		checkValidName(name);
		this.name = name;
	}
	
	/**
	 * Sets a new description
	 * @param description
	 */
	public void setDescription(String description) {
		checkValidDescription(description);
		this.description = description;
	}
	
	
	/*
	 * Getters
	 */
	
	/**
	 * Gets a task's ID
	 * @return ID
	 */
	public String getID() {
		return this.ID;
	}
	
	/**
	 * Gets a task's name
	 * @return name
	 */
	public String getName() {
		return this.name;
	}
	
	/**
	 * Gets a task's description
	 * @return description
	 */
	public String getDescription() {
		return this.description;
	}

	
}
