package Main;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.10
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class was developed as my interpretation from the identified requirements:
 * Contact Class Requirements
 * 	    The contact object shall have a required unique contact ID string that cannot be longer than 10 characters. The contact ID shall not be null and shall not be updatable.
 * 	    The contact object shall have a required firstName String field that cannot be longer than 10 characters. The firstName field shall not be null.
 * 	    The contact object shall have a required lastName String field that cannot be longer than 10 characters. The lastName field shall not be null.
 * 	    The contact object shall have a required phone String field that must be exactly 10 digits. The phone field shall not be null.
 * 	    The contact object shall have a required address field that must be no longer than 30 characters. The address field shall not be null.
 */

public class Contact {

	/*
	 * Attributes
	 */
	private final String ID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	/*
	 * Methods
	 */
	
	/**
	 * Constructor
	 * @param ID 
	 * @param first name 
	 * @param last name
	 * @param phone
	 * @param address
	 * @return new contact
	 */
	public Contact(String ID, String firstName, String lastName, String phone, String address) {
		checkValidID(ID);
		this.ID = ID;
		
		checkValidFirstName(firstName);
		this.firstName = firstName;
		
		checkValidLastName(lastName);
		this.lastName = lastName;
		
		checkValidAddress(address);
		this.address = address;
		
		String Phone = stripPhone(phone);
		checkValidPhone(Phone);
		this.phone = Phone;
	}
	
	/**
	 * Removes non-numeric characters from a given string
	 * @param The to-be-stripped string 
	 * @return stripped string
	 */
	private static String stripPhone(String inputPhone) {
		// Edgecase: string does not exist
		if (inputPhone == null) return null;
		
		// Convert string to char array, iterate through and build new string with only digits
		String phone = "";
		char[] chars = inputPhone.toCharArray();
		for (int i = 0; i < chars.length; i++) {
            if (Character.isDigit(chars[i])) phone += chars[i];
        }
		return phone;	
	}
	
	/*
	 * Input validation
	 */
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match ID criteria
	 * @param ID
	 */
	private static void checkValidID(String ID) {
		//// The contact object shall have a required unique contact ID string that cannot be longer than 10 characters. The contact ID shall not be null and shall not be updatable.
		if (ID == null || ID == "") throw new IllegalArgumentException("ID cannot be blank" ); // Is not null or zero- length
		if (ID.length() > 10) throw new IllegalArgumentException("ID cannot be longer than 10 characters" ); // is not more than ten characters
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match firstName criteria
	 * @param first name 
	 */
	private static void checkValidFirstName(String firstName) {
		// The contact object shall have a required firstName String field that cannot be longer than 10 characters. The firstName field shall not be null.
		if (firstName == null || firstName == "") throw new IllegalArgumentException("First name cannot be blank" );
		if (firstName.length() > 10) throw new IllegalArgumentException("First name cannot be longer than 10 characters" ); // is not more than ten characters
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match lastName criteria
	 * @param last name 
	 */
	private static void checkValidLastName(String lastName) {
		// The contact object shall have a required lastName String field that cannot be longer than 10 characters. The lastName field shall not be null.
		if (lastName == null || lastName == "") throw new IllegalArgumentException("Last name cannot be blank" );
		if (lastName.length() > 10) throw new IllegalArgumentException("Last name cannot be longer than 10 characters" ); // is not more than ten characters
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match phone criteria
	 * @param phone 
	 */
	private static void checkValidPhone(String phone) {
		// The contact object shall have a required phone String field that must be exactly 10 digits. The phone field shall not be null.
		if (phone == null || phone == "") throw new IllegalArgumentException("Phone cannot be blank" );
		if (phone.length() != 10) throw new IllegalArgumentException("Phone number must contain exactly 10 digits" ); // is ten digits
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match address criteria
	 * @param address 
	 */
	private static void checkValidAddress(String address) {
		// The contact object shall have a required address field that must be no longer than 30 characters. The address field shall not be null.
		if (address == null || address == "") throw new IllegalArgumentException("Address cannot be blank" );
		if (address.length() > 30) throw new IllegalArgumentException("Address cannot be longer than 30 characters" ); // is not more than ten characters
	}
	
	/*
	 * Setters
	 */
	
	/**
	 * Sets a new first name
	 * @param first name
	 */
	public void setFirstName(String firstName) {
		checkValidFirstName(firstName);
		this.firstName = firstName;
	}
	
	/**
	 * Sets a new last name
	 * @param last name
	 */
	public void setLastName(String lastName) {
		checkValidLastName(lastName);
		this.lastName = lastName;
	}
	
	/**
	 * Sets a new phone
	 * @param phone
	 */
	public void setPhone(String phone) {
		String Phone = stripPhone(phone);
		checkValidPhone(Phone);
		this.phone = Phone;
	}
	
	/**
	 * Sets a new address
	 * @param address
	 */
	public void setAddress(String address) {
		checkValidAddress(address);
		this.address = address;
	}
	
	
	/*
	 * Getters
	 */
	
	/**
	 * Gets a contact's ID
	 * @return ID
	 */
	public String getID() {
		return this.ID;
	}
	
	/**
	 * Gets a contact's first name
	 * @return first name
	 */
	public String getFirstName() {
		return this.firstName;
	}
	
	/**
	 * Gets a contact's last name
	 * @return last name
	 */
	public String getLastName() {
		return this.lastName;
	}
	
	/**
	 * Gets a contact's address
	 * @return address
	 */
	public String getAddress() {
		return this.address;
	}
	
	/**
	 * Gets a contact's phone (numbers only)
	 * @return phone (numbers only)
	 */
	public String getPhone() {
		return this.phone;
	}
	
	/**
	 * Gets a contact's phone ( (xxx) xxx-xxxx format)
	 * @return phone ( (xxx) xxx-xxxx format)
	 */
	public String getPhoneFormatted() {
		return "(" + this.phone.substring(0, 3) + ") " + this.phone.substring(3, 6) + "-" + this.phone.substring(6, 10);
	}
}


