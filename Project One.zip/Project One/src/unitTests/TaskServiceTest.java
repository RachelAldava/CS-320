package unitTests;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Main.Counter;
import Main.Task;
import Main.TaskService;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.11
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the TaskService class which was identified to have the following requirements:
 * Contact Service Requirements:
 * 
 * Task Service Requirements
 * 
 *     The task service shall be able to add tasks with a unique ID.
 *     The task service shall be able to delete tasks per task ID.
 *     The task service shall be able to update task fields per task ID. The following fields are updatable:
 *         Name
 *         Description
 * 
*/
public class TaskServiceTest {
	
	// ##############################################
	// #### Common values used by multiple tests ####
	// ##############################################

	// name String field that cannot be longer than 20 characters
	String name = "Assemble IKEA Chairs";// 20 characters
	
	//Description String field that cannot be longer than 50 characters
	String description = "First, we begin by inserting slot A into flange C3"; // 50 characters

	// Testing if we can create a new TaskService object
	// Testing if we can create a new task object
	// TEST PARTIALLY SATISFIES REQUIREMENT The task service shall be able to add tasks with a unique ID.
	// TEST SATISFIES RECOMMENDED TEST: Test adding a single task
	@Test
	void newServiceFunctions() {
		TaskService service = new TaskService();
		Task task = service.newTask(name, description);
		assertTrue(task.getID().equals("\""));
	}
	
	// Testing if we can create a TaskService object using overloaded constructor
	@Test
	void newServiceCustomCounterFunctions() {
		Counter counter = Counter.newNumberCounter();
		TaskService service = new TaskService(counter);
		Task task = service.newTask(name, description);
		assertTrue(task.getID().equals("1"));
	}
	
	// Testing if the service can retrieve a task by its ID
	// Testing if we can create a new task object
	// TEST SATISFIES REQUIREMENT The task service shall be able to add tasks with a unique ID.
	@Test
	void serviceCanRetrieveTaskObject() {
		TaskService service = new TaskService();
		Task task = service.newTask(name, description);
		Task retrievedTask = service.getTaskID(task.getID());
		assertTrue(retrievedTask.getID().equals(task.getID()));
	}
	
	// Testing if getTaskID will throw an error when supplied with a bad id
	@Test
	void getTaskIDThrowsError() {
		TaskService service = new TaskService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.getTaskID("Flamingo");
		});
	}
	
	// Testing if we can delete a task object
	// TEST SATISFIES REQUIREMENT The task service shall be able to delete tasks per task ID.
    // TEST SATISFIES PORTION OF RECOMMENDED TEST: Test updating and deleting tasks
	@Test
	void deleteTaskFunctions() {
		TaskService service = new TaskService();
		Task task = service.newTask(name, description);
		service.deleteTask(task.getID());
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteTask(task.getID());
		});
	}
	
	// Testing if we can create multiple tasks with the service and appropriately retrieve them.
	// TEST SATISFIES RECOMMENDED TEST: Test adding multiple tasks
	@Test
	void ServiceCanAddMultipleTasks() {
		TaskService service = new TaskService(Counter.newNumberCounter());
		for (int i = 0; i < 99; i++) {
			service.newTask(name, description);
		}
		Task task = service.newTask(name, description);
		String retrievedID = service.getTaskID(task.getID()).getID();
		assertTrue(retrievedID.equals("100"));
	}
	
	// Setter and getter tests
	// TEST SATISFIES REQUIREMENT: The task service shall be able to update task fields per task ID. The following fields are updatable:
    //		Name
    //		Description
	//

	// TEST SATISFIES RECOMMENDED TEST: Test adding and retrieving tasks from the service
    // TEST SATISFIES REMAINDER OF RECOMMENDED TEST: Test updating and deleting tasks
	@Test
	void updateFieldsFunctions() {
		TaskService service = new TaskService();
		Task task = service.newTask(name, description);
		service.setTaskName(task.getID(),"Empty Trash");
		service.setTaskDescription(task.getID(),"Lorem ipsum sic colores ilit requardium");
		assertTrue(service.getName(task.getID()).equals("Empty Trash"));
		assertTrue(service.getDescription(task.getID()).equals("Lorem ipsum sic colores ilit requardium"));
	}
	
	// Testing for error handling in the event of colliding ID values
	// TEST SATISFIES RECOMMENDED TEST: Test for errors with duplicate task ID
	// TEST SATISFIES REQUIREMENT: The task service shall be able to add tasks with a unique ID.
	@Test
	void CollidingIDThrowsError() {
		// NOTE: This type of Counter should cause TaskService to attempt to use "1" for all IDs
		Counter counter = Counter.newBrokenCounter("1");
		TaskService service = new TaskService(counter);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.newTask(name, description);
			service.newTask(name, description);
		});
	}
}