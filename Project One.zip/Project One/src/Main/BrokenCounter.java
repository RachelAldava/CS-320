package Main;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.03.30
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * Creates a simple input based "counter" with customizable string outputs
 * 
 * Operates by saving an input String and outputting that same string whenever it is called.
 * 
 * Use case: 
 * 		Testing classes which rely on a Counter object.
 * 
 * Limitations: 
 * 		This counter doesn't count.
 * 
 * Usage: Create object with a String, then call getNext() to retrieve the same string.
*/

public class BrokenCounter extends Counter{
	
	protected BrokenCounter(String string){
		this.ID= string;
	}

	@Override
	public void next() {
	}
	
	@Override
	public String get() {
		return this.ID;
	}
	
	@Override
	public String getNext() {
		return this.get();
	}
}
