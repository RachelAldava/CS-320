package Main;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.03.27
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * Creates a simple integer based counter with customizable string outputs
 * 
 * Operates by increasing an integer counter, then converts the int into 
 * 		a corresponding dictionary value.
 * 
 * Use case: 
 * 		Generating a high density of sequential ID numbers
 * 		Counting in user-defined mathematical bases
 * 
 * Limitations: 
 * 		Dictionary must be externally defined and retained in memory.
 * 		There is currently no toInt() method implemented.
 * 		There is currently no previous() method implemented.
 * 
 * Usage: Create object, then call getNext() to begin the counter.
*/

public class DictCounter extends Counter{
	
	private final char[] dict;
	private final int dictLen;
	private int count = 0;
	
	protected DictCounter(char[] dictionary){
		this.ID= null;
		this.dict = dictionary;
		this.dictLen = dictionary.length;
	}
	
	@Override
	public void next() {
		count++;
	}
	
	@Override
	public String get() {
		
		// Find magnitude
		int magnitude = 1;
		int curVal = count;
		while (curVal >= dictLen) {
			magnitude++;
			curVal /= dictLen;
		}
		
		// create space to store characters
		char chars[] = new char[magnitude];

		curVal = count;
		int digitNum;
		
		
		
		// for each character in the char array, in reverse order
		for (int i = magnitude -1; i >= 0; i--) {
			//System.out.println("iteration <"+ i+ "> mag:"+ magnitude);
			// find the value of the current digit in mathematical base {dictLen}
			digitNum = curVal % this.dictLen;
			
			// add the character to the char array
			//System.out.println("iteration <"+ i+ "> curVal:"+ curVal);
			chars[i] = dict[digitNum];
			
			// Reduce magnitude of the current value
			curVal -= digitNum;
			curVal /= this.dictLen;
		}
		
		// Build and return string
		String string = "";
		for (char c:chars) {
			string += c;
		}
		return string;

	}
	
	@Override
	public String getNext() {
		this.next();
		return this.get();
	}
}
