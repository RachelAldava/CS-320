package Main;
import java.util.HashMap;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.10
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class was developed as my interpretation from the identified requirements:
 * Contact Service Requirements:
 * 
 *    The contact service shall be able to add contacts with a unique ID.
 *    The contact service shall be able to delete contacts per contact ID.
 *    The contact service shall be able to update contact fields per contact ID. The following fields are updatable:
 *        firstName
 *        lastName
 *        Number
 *        Address
*/

public class ContactService {
	
	//##################################
	//####### Instance Variables #######
	//##################################
	
	// ID:Object key; This houses references to Task objects
	private HashMap<String, Contact> contacts = new HashMap<String, Contact>();
	
	// This object will provide sequential ID strings.
	private Counter IdCounter;

	//##################################
	//########## Constructors ##########
	//##################################
	
	/**
	 * Creates a new blank ContactService object
	 * @return new ContactService object
	 */
	public ContactService() {
		this.IdCounter = Counter.newSymbolCounter();
	}
	
	/**
	 * Creates a new blank ContactService object using IDs generated from the supplied counter.
	 * @param A Counter object
	 * @return new ContactService object
	 */
	public ContactService(Counter counter) {
		this.IdCounter = counter;
	}
	
	
	//##################################
	//######### Class  Methods #########
	//##################################
	
	
	//####### Creation : Deletion ######
	
	/**
	 * Creates a new Contact object
	 * @param first name 
	 * @param last name
	 * @param phone
	 * @param address
	 * @return new contact
	 */
	// The task service shall be able to add tasks with a unique ID.
	public Contact newContact(String firstName, String lastName, String phone, String address) {
		// Collect values
		Contact contact = new Contact(IdCounter.getNext(), firstName, lastName, phone, address);
		
		// Check for conflicting IDs
		// At time of writing (version 0.1), this can only occur if there is an issue 
		// within the Counter class or its children.
		if (contacts.containsKey(contact.getID())) throw new IllegalArgumentException("ERROR: Conflicting ID supplied");
		
		// Add task to list and return
		contacts.put(contact.getID(), contact);
		return contact;
	}
	
	/**
	 * Deletes a new Contact object
	 * @param ID
	 */
	// The contact service shall be able to delete contacts per contact ID.
	public void deleteContact(String ID) {
		if (!contacts.containsKey(ID)) throw new IllegalArgumentException("ID does not exist" ); // Is not in hashmap;
		contacts.remove(ID);
	}
	
	//####### Getters : Setters ########
	
	/**
	 * Returns a new Contact object
	 * @param ID
	 * @return contact
	 */
	public Contact getContactID(String ID) {
		if (!contacts.containsKey(ID)) throw new IllegalArgumentException("ID does not exist" ); // Is not in hashmap;
		return contacts.get(ID);
	}
	
	/**
	 * Changes firstName
	 * @param ID
	 * @param first name
	 */
	public void setContactFirstName(String ID, String firstName) {
		getContactID(ID).setFirstName(firstName);
	}
	
	/**
	 * Changes lastName
	 * @param ID
	 * @param last name
	 */
	public void setContactLastName(String ID, String lastName) {
		getContactID(ID).setLastName(lastName);
	}
	
	/**
	 * Changes phone
	 * @param ID
	 * @param phone
	 */
	public void setContactPhoneName(String ID, String phone) {
		getContactID(ID).setPhone(phone);
	}
	
	/**
	 * Changes address
	 * @param ID
	 * @param address
	 */
	public void setContactAddress(String ID, String address) {
		getContactID(ID).setAddress(address);
	}
}
