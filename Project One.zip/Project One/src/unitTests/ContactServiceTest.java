package unitTests;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Main.Contact;
import Main.ContactService;
import Main.Counter;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.10
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the ContactService class which was identified to have the following requirements:
 * Contact Service Requirements:
 * 
 *    The contact service shall be able to add contacts with a unique ID.
 *    The contact service shall be able to delete contacts per contact ID.
 *    The contact service shall be able to update contact fields per contact ID. The following fields are updatable:
 *        firstName
 *        lastName
 *        Number
 *        Address
*/

public class ContactServiceTest {
	
	// ##############################################
	// #### Common values used by multiple tests ####
	// ##############################################

	//ID String that cannot be longer than 10 characters
	String ID = "12345abcde";// 10 char
	
	//firstName String that cannot be longer than 10 characters
	String firstName = "Persephone";// 10 char
	
	//lastName String that cannot be longer than 10 characters
	String lastName = "MacDonnell";// 10 char
	

	//phone String that cannot be longer than 10 digits
	String phone = "(216) 245-2368";// 10 digits
	
	//address String that cannot be longer than 30 characters
	String address = "1600 Pennsylvania Avenue NW, W";// 30 char
	
	
	

	// Testing if we can create a new ContactService object
	// Testing if we can create a new contact object
	// TEST PARTIALLY SATISFIES REQUIREMENT The contact service shall be able to add contacts with a unique ID.
	@Test
	void newServiceFunctions() {
		ContactService service = new ContactService();
		Contact contact = service.newContact(firstName, lastName, phone, address);
		assertTrue(contact.getID().equals("\""));
	}
	
	// Testing if we can create a ContactService object using overloaded constructor
	@Test
	void newServiceCustomCounterFunctions() {
		Counter counter = Counter.newNumberCounter();
		ContactService service = new ContactService(counter);
		Contact contact = service.newContact(firstName, lastName, phone, address);
		assertTrue(contact.getID().equals("1"));
	}
	
	// Testing if the service can retrieve a contact by its ID
	// Testing if we can create a new contact object
	// TEST SATISFIES REQUIREMENT The contact service shall be able to add contacts with a unique ID.
	@Test
	void serviceCanRetrieveContactObject() {
		ContactService service = new ContactService();
		Contact contact = service.newContact(firstName, lastName, phone, address);
		Contact retrievedContact = service.getContactID(contact.getID());
		assertTrue(retrievedContact.getID().equals(contact.getID()));
	}
	
	// Testing if getContactID will throw an error when supplied with a bad id
	@Test
	void getContactIDThrowsError() {
		ContactService service = new ContactService();
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.getContactID("Flamingo");
		});
	}
	
	// Testing if we can delete a contact object
	// TEST SATISFIES REQUIREMENT The contact service shall be able to delete contacts per contact ID.
	@Test
	void deleteContactFunctions() {
		ContactService service = new ContactService();
		Contact contact = service.newContact(firstName, lastName, phone, address);
		service.deleteContact(contact.getID());
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.deleteContact(contact.getID());
		});
	}
	
	// Testing if we can create multiple contacts with the service and appropriately retrieve them.
	@Test
	void ServiceCanAddMultipleContacts() {
		ContactService service = new ContactService(Counter.newNumberCounter());
		for (int i = 0; i < 99; i++) {
			service.newContact(firstName, lastName, phone, address);
		}
		Contact contact = service.newContact(firstName, lastName, phone, address);
		String retrievedID = service.getContactID(contact.getID()).getID();
		assertTrue(retrievedID.equals("100"));
	}
	
	// Setter and getter tests
	// TEST SATISFIES REQUIREMENT: The contact service shall be able to update contact fields per contact ID. The following fields are updatable:
	//        firstName
	//        lastName
	//        Number
	//        Address
	@Test
	void updateFieldsFunctions() {
		ContactService service = new ContactService();
		// Create object and verify
		Contact contact = service.newContact(firstName, lastName, "(777) 777-7777", address);
		String ID = contact.getID();
		assertTrue(contact.getFirstName().equals(firstName));
		assertTrue(contact.getLastName().equals(lastName));
		assertTrue(contact.getPhone().equals("7777777777"));
		assertTrue(contact.getAddress().equals(address));
		
		// Change fields
		String newFirstName = "Elagabalus";
		String newLastName = "Antoninus";
		String newPhone = "(098) 765-4321";
		String newAddress = "Palatino del Colosseo,186 Roma";
		service.setContactFirstName(ID, newFirstName);
		service.setContactLastName(ID, newLastName);
		service.setContactPhoneName(ID, newPhone);
		service.setContactAddress(ID, newAddress);
		
		// Verify the change
		contact = service.getContactID(ID);
		assertTrue(contact.getFirstName().equals(newFirstName));
		assertTrue(contact.getLastName().equals(newLastName));
		assertTrue(contact.getPhone().equals("0987654321"));
		assertTrue(contact.getAddress().equals(newAddress));
	}
	
	// Testing for error handling in the event of colliding ID values
	// TEST SATISFIES RECOMMENDED TEST: Test for errors with duplicate contact ID
	// TEST SATISFIES REQUIREMENT: The contact service shall be able to add contacts with a unique ID.
	@Test
	void CollidingIDThrowsError() {
		// NOTE: This type of Counter should cause ContactService to attempt to use "1" for all IDs
		Counter counter = Counter.newBrokenCounter("1");
		ContactService service = new ContactService(counter);
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			service.newContact(firstName, lastName, phone, address);
			service.newContact(firstName, lastName, phone, address);
		});
	}

}
