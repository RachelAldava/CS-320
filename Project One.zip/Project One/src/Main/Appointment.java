package Main;

import java.util.Date;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.05
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class was developed as my interpretation from the identified requirements:
 * 
 * Appointment Class Requirements
 *	 The appointment object shall have a required unique appointment ID string that cannot be longer than 10 characters. The appointment ID shall not be null and shall not be updatable.
 *	 The appointment object shall have a required appointment Date field. The appointment Date field cannot be in the past. The appointment Date field shall not be null.
 *	 Note: Use java.util.Date for the appointmentDate field and use before(new Date()) to check if the date is in the past.
 *	 The appointment object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.

 */
public class Appointment {

	/*
	 * Attributes
	 */
	
	private final String ID;// The appointment object shall have a required unique appointment ID string that cannot be longer than 10 characters. The appointment ID shall not be null and shall not be updatable.
	private Date date;// The appointment object shall have a required appointment Date field. The appointment Date field cannot be in the past. The appointment Date field shall not be null.
	private String description;// The appointment object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.
	
	/*
	 * Methods
	 */
	
	/**
	 * Constructor
	 * @param ID 
	 * @param date 
	 * @param description
	 * @return new appointment
	 */
	public Appointment (String ID, Date date, String description) {
		checkValidID(ID);
		this.ID = ID;
		
		checkValidDate(date);
		this.date = date;
		
		checkValidDescription(description);
		this.description = description;		
	}
	
	/*
	 * Input validation
	 */
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match ID criteria
	 * @param ID
	 */
	private static void checkValidID(String ID) {
		//// The appointment object shall have a required unique appointment ID string that cannot be longer than 10 characters. The appointment ID shall not be null and shall not be updatable.
		if (ID == null || ID == "") throw new IllegalArgumentException("ID cannot be blank" ); // Is not null or zero- length
		if (ID.length() > 10) throw new IllegalArgumentException("ID cannot be longer than 10 characters" ); // is not more than ten characters
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match date criteria
	 * @param date
	 */
	private static void checkValidDate(Date date) {
		if (date == null || date.before(new Date())) throw new IllegalArgumentException("Date cannot be blank and must not be in the past" );
	}
	
	/**
	 * Throws IllegalArgumentException if supplied value does not match description criteria
	 * @param description
	 */
	private static void checkValidDescription(String description) {
		// The appointment object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.
		if (description == null || description == "") throw new IllegalArgumentException("Description cannot be blank" );
		if (description.length() > 50) throw new IllegalArgumentException("Description cannot be longer than 50 characters" ); // is not more than fifty characters
	}

	
	/*
	 * Setters
	 */
	
	/**
	 * Sets a new date
	 * @param date
	 */
	public void setDate(Date date) {
		checkValidDate(date);
		this.date = date;
	}
	
	/**
	 * Sets a new description
	 * @param description
	 */
	public void setDescription(String description) {
		checkValidDescription(description);
		this.description = description;
	}
	
	
	/*
	 * Getters
	 */
	
	/**
	 * Gets a appointment's ID
	 * @return ID
	 */
	public String getID() {
		return this.ID;
	}
	
	/**
	 * Gets a appointment's date
	 * @return date
	 */
	public Date getDate() {
		return this.date;
	}
	
	/**
	 * Gets a appointment's description
	 * @return description
	 */
	public String getDescription() {
		return this.description;
	}

	
}
