package unitTests;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Main.Appointment;
import java.util.Date

/* @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.05
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class was developed as my interpretation from the identified requirements:
 * 
 * Appointment Class Requirements
 *	 The appointment object shall have a required unique appointment ID string that cannot be longer than 10 characters. The appointment ID shall not be null and shall not be updatable.
 *	 The appointment object shall have a required appointment Date field. The appointment Date field cannot be in the past. The appointment Date field shall not be null.
 *	 Note: Use java.util.Date for the appointmentDate field and use before(new Date()) to check if the date is in the past.
 *	 The appointment object shall have a required description String field that cannot be longer than 50 characters. The description field shall not be null.

 */
;public class AppointmentTest {	
	/* Appointment Object:

    Test creating a appointment object
    Test for errors with long appointment ID, date, and Description
*/
	
	
	// ##############################################
	// #### Common values used by multiple tests ####
	// ##############################################
	
	//ID String that cannot be longer than 10 characters
	String ID = "12345abcde";// 10 char
	String IDShort = "12345abcd";// 9 char
	String IDLong = "12345abcdef";// 11 char
	
	//Description String field that cannot be longer than 50 characters
	String description = "Lorem ipsum sed aliena a republica nostra videtur."; // 50 characters
	String descriptionShort = "Lorem ipsum. O tempora, o mores! hic tamen vivit."; // 49 characters
	String descriptionLong = "Lorem ipsum illis merito accidet quicquid evenerit."; // 51 characters Verum sententia eius mihi non crudelis — quid enim in talis homines crudele fieri potest? — sed aliena a re publica nostra videtur. 
	
	// Dates of temporal past, present, and future.
	private Date now() {
		return new Date((new Date().getTime()) + 5000L); // Five seconds in the future
	}
	Date datePast = new Date(946706400000L);// y2k
	Date dateFuture = new Date(32503701600000L);// y3k

	// ##############################################
	// ############# Constructor  Tests #############
	// ##############################################
	
	// Constructor base test; verifies that an object can be created
	@Test
	void constructorBase() {
		//public Appointment (String ID, String date, String description) {
		Date date = now();
		Appointment appointment = new Appointment (ID, date, description);
		assertTrue(appointment.getID().equals(ID));
		assertTrue(appointment.getDate().equals(date));
		assertTrue(appointment.getDescription().equals(description));
	}
	
	// ################## ID tests ##################
	
	// Testing if class constructor responds properly when ID is null
	@Test
	void constructorIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (null, now(), description);
		});
	}
	
	// Testing if class constructor responds properly when ID is zero length
	@Test
	void constructorIDIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment ("", now(), description);
		});
	}
	
	// Testing if class constructor responds properly when ID is exactly ten
	@Test
	void constructorIDIsMaxLength() {
		Appointment appointment = new Appointment (ID, now(), description);
		assertTrue(appointment.getID().equals(ID));
	}
	
	// Testing if class constructor responds properly when ID is less than ten
		@Test
		void constructorIDIsShort() {
			Appointment appointment = new Appointment (IDShort, now(), description);
			assertTrue(appointment.getID().equals(IDShort));
		}
	
	// Testing if class constructor responds properly when ID length exceeds 10
	@Test
	void constructorIDIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (IDLong, now(), description);
		});
	}
	
	// ################ date tests ##################
	
	// Testing if class constructor responds properly when date is null
	@Test
	void constructorDateIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (ID, null, description);
		});
	}
	
	// Testing if class constructor responds properly when date is roughly present time
	@Test
	void constructorDateIsNow() {
		Date now = now();
		Appointment appointment = new Appointment (ID, now, description);
		assertTrue(appointment.getDate().equals(now));
	}
	
	// Testing if class constructor responds properly when date is significantly in the future
		@Test
		void constructorDateIsFuture() {
			Appointment appointment = new Appointment (ID, dateFuture, description);
			assertTrue(appointment.getDate().equals(dateFuture));
		}
	
	// Testing if class constructor responds properly when date significantly in the past
	@Test
	void constructorDateIsPast() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (ID, datePast, description);
		});
	}
	
	// ############ Description tests ###############
	
	// Testing if class constructor responds properly when date is null
	@Test
	void constructorDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (ID, now(), null);
		});
	}
	
	// Testing if class constructor responds properly when date is zero length
	@Test
	void constructorDescriptionIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (ID, now(), "");
		});
	}
	
	// Testing if class constructor responds properly when date is exactly twenty characters
	@Test
	void constructorDescriptionIsMaxLength() {
		Appointment appointment = new Appointment (ID, now(), description);
		assertTrue(appointment.getDescription().equals(description));
	}
	
	// Testing if class constructor responds properly when date is less than twenty characters
		@Test
		void constructorDescriptionIsShort() {
			Appointment appointment = new Appointment (ID, now(), descriptionShort);
			assertTrue(appointment.getDescription().equals(descriptionShort));
		}
	
	// Testing if class constructor responds properly when first date is more than twenty characters
	@Test
	void constructorDescriptionIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Appointment (ID, now(), descriptionLong);
		});
	}
	
	// ##############################################
	// ############ Setter:getter Tests #############
	// ##############################################

	// ############ Date Set/Get tests ##############

	// Testing if setter/getter methods respond properly when date is null
	@Test
	void setterDateIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(ID, now(), description);
			appointment.setDate(null);
		});
	}
	
	// Testing if setter/getter methods respond properly when date is roughly present time
		@Test
		void setterDateIsNow() {
			Appointment appointment = new Appointment(ID, now(), description);
			Date now = now();
			appointment.setDate(now);
			assertTrue(appointment.getDate().equals(now));
		}
	
	// Testing if setter/getter methods respond properly when date is significantly in the future
	@Test
	void setterDateIsFuture() {
		Appointment appointment = new Appointment(ID, now(), description);
		appointment.setDate(dateFuture);
		assertTrue(appointment.getDate().equals(dateFuture));
	}
	
	// Testing if setter/getter methods respond properly when date is significantly in the past
		@Test
		void setterDateIsPast() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
				Appointment appointment = new Appointment(ID, now(), description);
				appointment.setDate(datePast);
			});
		}
	
	// ######### Description Set/Get tests ##########

	// Testing if setter/getter methods respond properly when description is null
	@Test
	void setterDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(ID, now(), description);
			appointment.setDescription(null);
		});
	}
	
	// Testing if setter/getter methods respond properly when description is zero length
	@Test
	void setterDescriptionIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(ID, now(), description);
			appointment.setDescription("");
		});
	}
	
	// Testing if setter/getter methods respond properly when description is exactly fifty characters
	@Test
	void setterDescriptionIsMaxLength() {
		Appointment appointment = new Appointment(ID, now(), description);
		appointment.setDescription(description);
		assertTrue(appointment.getDescription().equals(description));
	}
	
	// Testing if setter/getter methods respond properly when description is shorter than fifty characters
	@Test
	void setterDescriptionIsShort() {
		Appointment appointment = new Appointment(ID, now(), description);
		appointment.setDescription(descriptionShort);
		assertTrue(appointment.getDescription().equals(descriptionShort));
	}
	
	// Testing if setter/getter methods respond properly when description is too long
	@Test
	void setterDescriptionIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Appointment appointment = new Appointment(ID, now(), description);
			appointment.setDescription(descriptionLong);
		});
	}
}

