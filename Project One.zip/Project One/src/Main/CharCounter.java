package Main;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.04.11
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * Creates a simple string-based counter 
 * 
 * Operates by reading character values from a string, 
 * 		finding the leftmost string which can be increased,
 * 		then increasing the ASCII value by 1.
 * 
 * Use case: Generating a high density of sequential ID numbers
 * Limitations: 
 * 		ASCII values must be sequential
 * 		There is currently no toInt() method implemented.
 * 		There is currently no previous() method implemented.
 * 
 * 
 * Usage: Create object, then call getNext() to begin the counter.
*/
public class CharCounter extends Counter{
	private int charstart;
	private int charstop;
	
	/**
	 * Creates a new counter
	 * @return new counter
	 */
	//public IdCounter(){
	protected CharCounter(int start, int stop){
		this.charstart = start;
		this.charstop = stop;
		ID = String.valueOf((char)start);
	}

	
	/**
	 * Increases the counter and returns the new string value
	 * @return new string
	 */

	@Override
	public String getNext() {
		this.next();
		return this.get();
	}
	
	/**
	 * returns current string value
	 * @return current string
	 */
	public String get() {
		return this.ID;
		}
	
	/**
	 * Increases the counter by one step
	 */
	public void next() {
		// Iterate the rightmost character, if applicable. Moves left and tries again.
		char[] chars = this.ID.toCharArray();
		
		// While we have not iterated a character
		boolean needsIterating = true;
		int index = chars.length - 1;
		
		while (needsIterating) {
			if (index >= 0 && chars[index] < this.charstop) {
				//add one
				chars[index] += 1;
				
				// If this line is reached, we successfully iterated one character.
				needsIterating = false;
			}
			else if(index < 0){
				// If there are no more left-most characters, that means we need to lengthen the string by one character.
				this.ID = String.valueOf((char)(charstart + 1));
				this.ID += new String(new char[this.ID.length()]).replace('\0', (char)charstart);
				return;
			}
			else {
				index -= 1;
			}
		}
		
		
		// Build the new string
		String returnedString = "";
		for (char c : chars) returnedString += c;
		
		// save and return
		this.ID = returnedString;
		return;
	}

}
