package unitTests;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import Main.Task;

/**
 * @author Rachel Aldava
 * @version 1.0
 * revised: 2024.03.29
 * 
 * This class was written as part of a larger project for SNHU-CS-320 "Software Test Automation".
 * 
 * This class contains unit tests for the Task class which was identified to have the following requirements:
 * Task Class Requirements
 * 
 *     The task object shall have a required unique task ID String that cannot be longer than 10 characters. The task ID shall not be null and shall not be updatable.
 *     The task object shall have a required name String field that cannot be longer than 20 characters. The name field shall not be null.
 *     The task object shall have a required Description String field that cannot be longer than 50 characters. The Description field shall not be null.
 * 
*/
public class TaskTest {
	
	/* Task Object:

    Test creating a task object
    Test for errors with long task ID, name, and Description
*/
	
	
	// ##############################################
	// #### Common values used by multiple tests ####
	// ##############################################
	
	//ID String that cannot be longer than 10 characters
	String ID = "12345abcde";// 10 char
	String IDShort = "12345abcd";// 9 char
	String IDLong = "12345abcdef";// 11 char
	
	// name String field that cannot be longer than 20 characters
	String name = "Assemble IKEA Chairs";// 20 characters
	String nameShort = "Assemble IKEA Table";// 19 characters
	String nameLong = "Assemble IKEA Cabinet";// 21 characters
	
	//Description String field that cannot be longer than 50 characters
	String description = "First, we begin by inserting slot A into flange C3"; // 50 characters
	String descriptionShort = "First, we begin by inserting slot A into flange C"; // 49 characters
	String descriptionLong = "First, we begin by inserting slot A' into flange C3"; // 51 characters

	// ##############################################
	// ############# Constructor  Tests #############
	// ##############################################
	
	// Constructor base test; verifies that an object can be created
	@Test
	void constructorBase() {
		//public Task (String ID, String name, String description) {
		Task task = new Task (ID, name, description);
		assertTrue(task.getID().equals(ID));
		assertTrue(task.getName().equals(name));
		assertTrue(task.getDescription().equals(description));
	}
	
	// ################## ID tests ##################
	
	// Testing if class constructor responds properly when ID is null
	@Test
	void constructorIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (null, name, description);
		});
	}
	
	// Testing if class constructor responds properly when ID is zero length
	@Test
	void constructorIDIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task ("", name, description);
		});
	}
	
	// Testing if class constructor responds properly when ID is exactly ten
	@Test
	void constructorIDIsMaxLength() {
		Task task = new Task (ID, name, description);
		assertTrue(task.getID().equals(ID));
	}
	
	// Testing if class constructor responds properly when ID is less than ten
		@Test
		void constructorIDIsShort() {
			Task task = new Task (IDShort, name, description);
			assertTrue(task.getID().equals(IDShort));
		}
	
	// Testing if class constructor responds properly when ID length exceeds 10
	@Test
	void constructorIDIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (IDLong, name, description);
		});
	}
	
	// ################ name tests ##################
	
	// Testing if class constructor responds properly when name is null
	@Test
	void constructorNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (ID, null, description);
		});
	}
	
	// Testing if class constructor responds properly when name is zero length
	@Test
	void constructorNameIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (ID, "", description);
		});
	}
	
	// Testing if class constructor responds properly when name is exactly twenty characters
	@Test
	void constructorNameIsMaxLength() {
		Task task = new Task (ID, name, description);
		assertTrue(task.getName().equals(name));
	}
	
	// Testing if class constructor responds properly when name is less than twenty characters
		@Test
		void constructorNameIsShort() {
			Task task = new Task (ID, nameShort, description);
			assertTrue(task.getName().equals(nameShort));
		}
	
	// Testing if class constructor responds properly when first name is more than twenty characters
	@Test
	void constructorNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (ID, nameLong, description);
		});
	}
	
	// ############ Description tests ###############
	
	// Testing if class constructor responds properly when name is null
	@Test
	void constructorDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (ID, name, null);
		});
	}
	
	// Testing if class constructor responds properly when name is zero length
	@Test
	void constructorDescriptionIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (ID, name, "");
		});
	}
	
	// Testing if class constructor responds properly when name is exactly twenty characters
	@Test
	void constructorDescriptionIsMaxLength() {
		Task task = new Task (ID, name, description);
		assertTrue(task.getDescription().equals(description));
	}
	
	// Testing if class constructor responds properly when name is less than twenty characters
		@Test
		void constructorDescriptionIsShort() {
			Task task = new Task (ID, name, descriptionShort);
			assertTrue(task.getDescription().equals(descriptionShort));
		}
	
	// Testing if class constructor responds properly when first name is more than twenty characters
	@Test
	void constructorDescriptionIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task (ID, name, descriptionLong);
		});
	}
	
	// ##############################################
	// ############ Setter:getter Tests #############
	// ##############################################

	// ############ Name Set/Get tests ##############

	// Testing if setter/getter methods respond properly when name is null
	@Test
	void setterNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(ID, name, description);
			task.setName(null);
		});
	}
	
	// Testing if setter/getter methods respond properly when name is zero length
	@Test
	void setterNameIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(ID, name, description);
			task.setName("");
		});
	}
	
	// Testing if setter/getter methods respond properly when name is exactly twenty characters
	@Test
	void setterNameIsMaxLength() {
		Task task = new Task(ID, name, description);
		task.setName(name);
		assertTrue(task.getName().equals(name));
	}
	
	// Testing if setter/getter methods respond properly when name is shorter than twenty characters
		@Test
		void setterNameIsShort() {
			Task task = new Task(ID, name, description);
			task.setName(nameShort);
			assertTrue(task.getName().equals(nameShort));
		}
	
	// Testing if setter/getter methods respond properly when name is too long
	@Test
	void setterNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(ID, name, description);
			task.setName(nameLong);
		});
	}
	
	// ######### Description Set/Get tests ##########

	// Testing if setter/getter methods respond properly when description is null
	@Test
	void setterDescriptionIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(ID, name, description);
			task.setDescription(null);
		});
	}
	
	// Testing if setter/getter methods respond properly when description is zero length
	@Test
	void setterDescriptionIsZeroLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(ID, name, description);
			task.setDescription("");
		});
	}
	
	// Testing if setter/getter methods respond properly when description is exactly fifty characters
	@Test
	void setterDescriptionIsMaxLength() {
		Task task = new Task(ID, name, description);
		task.setDescription(description);
		assertTrue(task.getDescription().equals(description));
	}
	
	// Testing if setter/getter methods respond properly when description is shorter than fifty characters
	@Test
	void setterDescriptionIsShort() {
		Task task = new Task(ID, name, description);
		task.setDescription(descriptionShort);
		assertTrue(task.getDescription().equals(descriptionShort));
	}
	
	// Testing if setter/getter methods respond properly when description is too long
	@Test
	void setterDescriptionIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			Task task = new Task(ID, name, description);
			task.setDescription(descriptionLong);
		});
	}

}
